"""
Crebain API Python SDK.

A lightweight, typed client for the Crebain API.

Example:
    >>> from crebain_client import CrebainClient
    >>> client = CrebainClient(
    ...     api_key="ck_live_...",
    ...     base_url="https://xxx.supabase.co/functions/v1/api"
    ... )
    >>> entities = client.list_entities()
    >>> for entity in entities.entities:
    ...     print(entity.name)
"""

from .client import CrebainClient
from .errors import (
    ApiError,
    ConflictError,
    ForbiddenError,
    InternalError,
    NotFoundError,
    RateLimitedError,
    UnauthorizedError,
    ValidationError,
)
from .models import (
    EntitiesPage,
    Entity,
    EntitySubmitResult,
    FileItem,
    FilesFromUrlsResult,
    PersonSubmitResult,
    RequestInfo,
    RequestsPage,
    RequestSummary,
    WebhookSubscription,
)
from .webhooks import compute_signature, verify_signature

__version__ = "1.0.0"

__all__ = [
    # Client
    "CrebainClient",
    # Errors
    "ApiError",
    "UnauthorizedError",
    "ForbiddenError",
    "NotFoundError",
    "ConflictError",
    "ValidationError",
    "RateLimitedError",
    "InternalError",
    # Models
    "Entity",
    "EntitiesPage",
    "FileItem",
    "EntitySubmitResult",
    "FilesFromUrlsResult",
    "PersonSubmitResult",
    "RequestInfo",
    "RequestsPage",
    "RequestSummary",
    "WebhookSubscription",
    # Webhooks
    "verify_signature",
    "compute_signature",
]
