"""
Crebain API client.

Provides a typed, easy-to-use interface for the Crebain API.
"""

from typing import Any, Iterator
from urllib.parse import urljoin

import requests

from .errors import ApiError, raise_for_error
from .models import (
    EntitiesPage,
    Entity,
    EntitySubmitResult,
    FilesFromUrlsResult,
    PersonSubmitResult,
    RequestInfo,
    RequestsPage,
    WebhookSubscription,
)


class CrebainClient:
    """
    Client for the Crebain API.

    Args:
        api_key: Your API key (format: ck_live_...)
        base_url: Base URL of the API (e.g., https://xxx.supabase.co/functions/v1/api)
        supabase_anon_key: Supabase anonymous key for gateway authentication (optional)
        timeout: Request timeout in seconds (default: 30.0)

    Example:
        >>> client = CrebainClient(
        ...     api_key="ck_live_...",
        ...     base_url="https://xxx.supabase.co/functions/v1/api",
        ...     supabase_anon_key="eyJhbG..."
        ... )
        >>> entities = client.list_entities(limit=10)
        >>> for entity in entities.entities:
        ...     print(entity.name)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        supabase_anon_key: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._session = requests.Session()
        headers = {
            "X-API-Key": api_key,
            "Content-Type": "application/json",
        }
        if supabase_anon_key:
            headers["Authorization"] = f"Bearer {supabase_anon_key}"
        self._session.headers.update(headers)

    def _url(self, path: str) -> str:
        """Build full URL from path."""
        return f"{self.base_url}{path}"

    def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> tuple[dict[str, Any], str]:
        """
        Make an API request and return parsed response data and request_id.

        Args:
            method: HTTP method
            path: API path (e.g., /v1/entities)
            params: Query parameters
            json: JSON body
            headers: Additional headers

        Returns:
            Tuple of (response data dict, request_id)

        Raises:
            ApiError: On non-2xx responses
        """
        url = self._url(path)
        request_headers = dict(self._session.headers)
        if headers:
            request_headers.update(headers)

        response = self._session.request(
            method=method,
            url=url,
            params=params,
            json=json,
            headers=request_headers,
            timeout=self.timeout,
        )

        # Try to parse JSON response
        try:
            body = response.json()
        except ValueError:
            body = response.text

        # Check for errors
        if not response.ok:
            raise_for_error(response.status_code, body)

        # Extract data and request_id from success envelope
        if isinstance(body, dict):
            request_id = body.get("request_id", "")
            data = body.get("data", body)
            return data, request_id

        return body, ""

    def list_entities(
        self,
        limit: int = 50,
        cursor: str | None = None,
    ) -> EntitiesPage:
        """
        List entities with pagination.

        Args:
            limit: Number of entities to return (max 200, default 50)
            cursor: Pagination cursor from previous response

        Returns:
            EntitiesPage with entities and optional next_cursor

        Example:
            >>> page = client.list_entities(limit=10)
            >>> for entity in page.entities:
            ...     print(entity.name)
            >>> if page.next_cursor:
            ...     next_page = client.list_entities(cursor=page.next_cursor)
        """
        params: dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor

        data, request_id = self._request("GET", "/v1/entities", params=params)
        return EntitiesPage.from_response(data, request_id)

    def iter_entities(self, limit: int = 200) -> Iterator[Entity]:
        """
        Iterate over all entities with automatic pagination.

        Args:
            limit: Number of entities per page (max 200)

        Yields:
            Entity objects

        Example:
            >>> for entity in client.iter_entities():
            ...     print(f"{entity.id}: {entity.name}")
        """
        cursor: str | None = None
        while True:
            page = self.list_entities(limit=limit, cursor=cursor)
            yield from page.entities
            if not page.next_cursor:
                break
            cursor = page.next_cursor

    def submit_entity(
        self,
        external_entity_id: str | None = None,
        name: str | None = None,
        company_description: str | None = None,
        metadata: dict[str, Any] | None = None,
        force: bool = False,
        adverse_news_only: bool = False,
        fields: list[str] | None = None,
        idempotency_key: str | None = None,
    ) -> EntitySubmitResult:
        """
        Submit an entity for enrichment.

        Args:
            external_entity_id: External identifier (unique per org)
            name: Entity name
            company_description: Brief description of the company (for enrichment context)
            metadata: Additional metadata
            force: Force enrichment even if files exist
            adverse_news_only: Only check for adverse news
            fields: Filter returned outputs to specific field types (response filtering only).
                    Allowed values: Adverse_news_founder, Adverse_news_directors,
                    Adverse_news_entities, Corporate_graph_funding_vehicles,
                    People_control_report, Director_graph
            idempotency_key: Unique key for idempotent request handling

        Returns:
            EntitySubmitResult with entity_id and status

        Example:
            >>> result = client.submit_entity(
            ...     external_entity_id="customer-123",
            ...     name="Acme Corp",
            ...     company_description="Global fintech company",
            ...     fields=["People_control_report", "Director_graph"],
            ...     idempotency_key="unique-key-123"
            ... )
            >>> print(f"Entity ID: {result.entity_id}")
            >>> if result.request_submitted:
            ...     print(f"Async request: {result.async_request_id}")
        """
        body: dict[str, Any] = {}
        if external_entity_id is not None:
            body["external_entity_id"] = external_entity_id
        if name is not None:
            body["name"] = name
        if company_description is not None:
            body["company_description"] = company_description
        if metadata is not None:
            body["metadata"] = metadata
        if force:
            body["force"] = True
        if adverse_news_only:
            body["adverse_news_only"] = True
        if fields is not None:
            body["fields"] = fields

        headers: dict[str, str] = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        data, request_id = self._request(
            "POST",
            "/v1/entity/submit",
            json=body,
            headers=headers if headers else None,
        )
        return EntitySubmitResult.from_response(data, request_id)

    def submit_person(
        self,
        name: str,
        company_name: str | None = None,
        entity_id: str | None = None,
        idempotency_key: str | None = None,
    ) -> PersonSubmitResult:
        """
        Submit a person for adverse news check (founder-focused).

        Args:
            name: Person's full name (required)
            company_name: Optional company name for context
            entity_id: Optional entity ID to associate the person with
            idempotency_key: Unique key for idempotent request handling

        Returns:
            PersonSubmitResult with request status and files (when available)

        Example:
            >>> result = client.submit_person(
            ...     name="John Smith",
            ...     company_name="Acme Corp",
            ...     entity_id="entity-uuid-123"
            ... )
            >>> print(f"Request submitted: {result.request_submitted}")
            >>> if result.async_request_id:
            ...     print(f"Async Request ID: {result.async_request_id}")
        """
        body: dict[str, Any] = {"name": name}
        if company_name is not None:
            body["company_name"] = company_name
        if entity_id is not None:
            body["entity_id"] = entity_id

        headers: dict[str, str] = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        data, request_id = self._request(
            "POST",
            "/v1/person/submit",
            json=body,
            headers=headers if headers else None,
        )
        return PersonSubmitResult.from_response(data, request_id)

    def get_request(self, request_id: str) -> RequestInfo:
        """
        Get details of an async request by ID.

        Args:
            request_id: The async request ID

        Returns:
            RequestInfo with status, payload, result, and files (if complete)

        Example:
            >>> info = client.get_request("request-uuid-123")
            >>> print(f"Status: {info.status}")
            >>> if info.status == "complete":
            ...     for file in info.files:
            ...         print(f"File: {file.filename}")
        """
        data, api_request_id = self._request("GET", f"/v1/requests/{request_id}")
        return RequestInfo.from_response(data, api_request_id)

    def list_requests(
        self,
        limit: int = 50,
        cursor: str | None = None,
        status: str | None = None,
        kind: str | None = None,
    ) -> RequestsPage:
        """
        List async requests with pagination and optional filters.

        Args:
            limit: Number of requests to return (max 200, default 50)
            cursor: Pagination cursor from previous response
            status: Filter by status (submitted, processing, complete, failed)
            kind: Filter by kind (entity_enrich, url_ingest)

        Returns:
            RequestsPage with requests and optional next_cursor

        Example:
            >>> page = client.list_requests(status="complete", limit=10)
            >>> for req in page.requests:
            ...     print(f"{req.id}: {req.status}")
        """
        params: dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        if status:
            params["status"] = status
        if kind:
            params["kind"] = kind

        data, request_id = self._request("GET", "/v1/requests", params=params)
        return RequestsPage.from_response(data, request_id)

    def files_from_urls(
        self,
        url_list: list[str],
        entity_id: str | None = None,
        force: bool = False,
        idempotency_key: str | None = None,
    ) -> FilesFromUrlsResult:
        """
        Get files from URLs or trigger ingestion for missing ones.

        Args:
            url_list: List of URLs to fetch files from (max 50)
            entity_id: Optional entity to associate files with
            force: Force re-ingestion of all URLs
            idempotency_key: Unique key for idempotent request handling

        Returns:
            FilesFromUrlsResult with available files, missing URLs, and status

        Example:
            >>> result = client.files_from_urls(
            ...     url_list=["https://example.com/doc.pdf"],
            ...     idempotency_key="ingest-123"
            ... )
            >>> for file in result.files:
            ...     print(f"Available: {file.filename} -> {file.signed_url}")
            >>> for url in result.missing:
            ...     print(f"Queued for ingestion: {url}")
        """
        body: dict[str, Any] = {"url_list": url_list}
        if entity_id is not None:
            body["entity_id"] = entity_id
        if force:
            body["force"] = True

        headers: dict[str, str] = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        data, request_id = self._request(
            "POST",
            "/v1/files/from-urls",
            json=body,
            headers=headers if headers else None,
        )
        return FilesFromUrlsResult.from_response(data, request_id)

    def create_webhook(
        self,
        url: str,
        secret: str,
        idempotency_key: str | None = None,
    ) -> WebhookSubscription:
        """
        Create a webhook subscription.

        Args:
            url: Webhook endpoint URL (must be HTTPS)
            secret: Secret for HMAC signature verification (min 16 chars)
            idempotency_key: Unique key for idempotent request handling

        Returns:
            WebhookSubscription with the created webhook details

        Example:
            >>> webhook = client.create_webhook(
            ...     url="https://myserver.com/webhook",
            ...     secret="whsec_my_secret_key_here"
            ... )
            >>> print(f"Webhook ID: {webhook.id}")
        """
        body = {"url": url, "secret": secret}

        headers: dict[str, str] = {}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        data, request_id = self._request(
            "POST",
            "/v1/webhooks",
            json=body,
            headers=headers if headers else None,
        )
        return WebhookSubscription.from_dict(data)

    def list_webhooks(self) -> list[WebhookSubscription]:
        """
        List all webhook subscriptions.

        Returns:
            List of WebhookSubscription objects

        Example:
            >>> webhooks = client.list_webhooks()
            >>> for wh in webhooks:
            ...     print(f"{wh.id}: {wh.url} (enabled={wh.enabled})")
        """
        data, request_id = self._request("GET", "/v1/webhooks")
        return [WebhookSubscription.from_dict(w) for w in data.get("webhooks", [])]

    def delete_webhook(self, webhook_id: str) -> None:
        """
        Delete a webhook subscription.

        Args:
            webhook_id: ID of the webhook to delete

        Raises:
            NotFoundError: If the webhook doesn't exist

        Example:
            >>> client.delete_webhook("webhook-uuid-here")
        """
        self._request("DELETE", f"/v1/webhooks/{webhook_id}")

    def close(self) -> None:
        """Close the underlying HTTP session."""
        self._session.close()

    def __enter__(self) -> "CrebainClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
