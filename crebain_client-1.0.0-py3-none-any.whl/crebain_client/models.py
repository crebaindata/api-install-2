"""
Crebain API data models.

All models are lightweight dataclasses for easy serialization and type safety.
"""

from dataclasses import dataclass
from typing import Any


@dataclass
class Entity:
    """
    Represents an entity in the system.

    Attributes:
        id: Unique entity identifier (UUID)
        external_entity_id: External identifier (unique per org)
        name: Entity name
        metadata: Additional metadata as a dictionary
        created_at: ISO 8601 timestamp of creation
        updated_at: ISO 8601 timestamp of last update
    """

    id: str
    external_entity_id: str | None
    name: str | None
    metadata: dict[str, Any]
    created_at: str
    updated_at: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Entity":
        """Create an Entity from an API response dictionary."""
        return cls(
            id=data["id"],
            external_entity_id=data.get("external_entity_id"),
            name=data.get("name"),
            metadata=data.get("metadata", {}),
            created_at=data["created_at"],
            updated_at=data["updated_at"],
        )


@dataclass
class EntitiesPage:
    """
    A paginated page of entities.

    Attributes:
        entities: List of entities on this page
        next_cursor: Cursor for the next page, or None if no more pages
        request_id: Request ID from the API response
    """

    entities: list[Entity]
    next_cursor: str | None
    request_id: str

    @classmethod
    def from_response(cls, data: dict[str, Any], request_id: str) -> "EntitiesPage":
        """Create an EntitiesPage from an API response."""
        return cls(
            entities=[Entity.from_dict(e) for e in data.get("entities", [])],
            next_cursor=data.get("next_cursor"),
            request_id=request_id,
        )


@dataclass
class FileItem:
    """
    Represents a file in the system.

    Attributes:
        file_id: Unique file identifier (UUID)
        filename: File name
        mime_type: MIME type of the file
        bytes: File size in bytes
        source_url: Original URL the file was fetched from
        signed_url: Temporary signed URL for downloading (valid ~1 hour)
        created_at: ISO 8601 timestamp of creation
    """

    file_id: str
    filename: str
    mime_type: str | None
    bytes: int | None
    source_url: str | None
    signed_url: str | None
    created_at: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FileItem":
        """Create a FileItem from an API response dictionary."""
        return cls(
            file_id=data["file_id"],
            filename=data["filename"],
            mime_type=data.get("mime_type"),
            bytes=data.get("bytes"),
            source_url=data.get("source_url"),
            signed_url=data.get("signed_url"),
            created_at=data["created_at"],
        )


@dataclass
class EntitySubmitResult:
    """
    Result of an entity submit operation.

    Attributes:
        entity_id: The entity's UUID (created or found)
        new_company: True if the entity was created by this request
        existing_files: List of files already available for this entity
        request_submitted: True if an enrichment request was queued
        async_request_id: ID of the async request (if submitted)
        request_id: API request ID for debugging
    """

    entity_id: str
    new_company: bool
    existing_files: list[FileItem]
    request_submitted: bool
    async_request_id: str | None
    request_id: str

    @classmethod
    def from_response(cls, data: dict[str, Any], request_id: str) -> "EntitySubmitResult":
        """Create an EntitySubmitResult from an API response."""
        files = data.get("existing_files", [])
        return cls(
            entity_id=data["entity_id"],
            new_company=data["new_company"],
            existing_files=[
                FileItem(
                    file_id=f["file_id"],
                    filename=f["filename"],
                    mime_type=f.get("mime_type"),
                    bytes=f.get("bytes"),
                    source_url=f.get("source_url"),
                    signed_url=f.get("signed_url"),
                    created_at=f["created_at"],
                )
                for f in files
            ],
            request_submitted=data["request_submitted"],
            async_request_id=data.get("async_request_id"),
            request_id=request_id,
        )


@dataclass
class PersonSubmitResult:
    """
    Result of a person submit operation (adverse news for founders).

    Attributes:
        person_name: The person's name that was submitted
        company_name: The company name (if provided)
        entity_id: The entity ID (if provided)
        existing_files: List of files available (Adverse_news_founder outputs)
        request_submitted: True if an async request was queued
        async_request_id: ID of the async request (if submitted)
        request_id: API request ID for debugging
    """

    person_name: str
    company_name: str | None
    entity_id: str | None
    existing_files: list[FileItem]
    request_submitted: bool
    async_request_id: str | None
    request_id: str

    @classmethod
    def from_response(cls, data: dict[str, Any], request_id: str) -> "PersonSubmitResult":
        """Create a PersonSubmitResult from an API response."""
        files = data.get("existing_files", [])
        return cls(
            person_name=data["person_name"],
            company_name=data.get("company_name"),
            entity_id=data.get("entity_id"),
            existing_files=[
                FileItem(
                    file_id=f["file_id"],
                    filename=f["filename"],
                    mime_type=f.get("mime_type"),
                    bytes=f.get("bytes"),
                    source_url=f.get("source_url"),
                    signed_url=f.get("signed_url"),
                    created_at=f["created_at"],
                )
                for f in files
            ],
            request_submitted=data["request_submitted"],
            async_request_id=data.get("async_request_id"),
            request_id=request_id,
        )


@dataclass
class RequestInfo:
    """
    Information about an async request.

    Attributes:
        id: Request ID
        kind: Request kind (entity_enrich, url_ingest)
        status: Request status (submitted, processing, complete, failed)
        payload: Request payload
        result: Request result (if complete)
        files: Associated files with signed URLs (if complete)
        created_at: ISO 8601 timestamp of creation
        updated_at: ISO 8601 timestamp of last update
        completed_at: ISO 8601 timestamp of completion (if complete)
        request_id: API request ID for debugging
    """

    id: str
    kind: str
    status: str
    payload: dict[str, Any]
    result: dict[str, Any] | None
    files: list[FileItem]
    created_at: str
    updated_at: str
    completed_at: str | None
    request_id: str

    @classmethod
    def from_response(cls, data: dict[str, Any], request_id: str) -> "RequestInfo":
        """Create a RequestInfo from an API response."""
        files = data.get("files", [])
        return cls(
            id=data["id"],
            kind=data["kind"],
            status=data["status"],
            payload=data.get("payload", {}),
            result=data.get("result"),
            files=[
                FileItem(
                    file_id=f["file_id"],
                    filename=f["filename"],
                    mime_type=f.get("mime_type"),
                    bytes=f.get("bytes"),
                    source_url=f.get("source_url"),
                    signed_url=f.get("signed_url"),
                    created_at=f["created_at"],
                )
                for f in files
            ],
            created_at=data["created_at"],
            updated_at=data["updated_at"],
            completed_at=data.get("completed_at"),
            request_id=request_id,
        )


@dataclass
class RequestSummary:
    """
    Summary of an async request (for list view).

    Attributes:
        id: Request ID
        kind: Request kind
        status: Request status
        payload: Request payload
        result: Request result (if complete)
        created_at: ISO 8601 timestamp of creation
        updated_at: ISO 8601 timestamp of last update
        completed_at: ISO 8601 timestamp of completion (if complete)
    """

    id: str
    kind: str
    status: str
    payload: dict[str, Any]
    result: dict[str, Any] | None
    created_at: str
    updated_at: str
    completed_at: str | None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RequestSummary":
        """Create a RequestSummary from an API response dictionary."""
        return cls(
            id=data["id"],
            kind=data["kind"],
            status=data["status"],
            payload=data.get("payload", {}),
            result=data.get("result"),
            created_at=data["created_at"],
            updated_at=data["updated_at"],
            completed_at=data.get("completed_at"),
        )


@dataclass
class RequestsPage:
    """
    A paginated page of requests.

    Attributes:
        requests: List of requests on this page
        next_cursor: Cursor for the next page, or None if no more pages
        request_id: API request ID for debugging
    """

    requests: list[RequestSummary]
    next_cursor: str | None
    request_id: str

    @classmethod
    def from_response(cls, data: dict[str, Any], request_id: str) -> "RequestsPage":
        """Create a RequestsPage from an API response."""
        return cls(
            requests=[RequestSummary.from_dict(r) for r in data.get("requests", [])],
            next_cursor=data.get("next_cursor"),
            request_id=request_id,
        )


@dataclass
class FilesFromUrlsResult:
    """
    Result of a files-from-urls operation.

    Attributes:
        files: List of files already available with signed URLs
        missing: List of URLs that need to be ingested
        request_submitted: True if an ingestion request was queued
        async_request_id: ID of the async request (if submitted)
        request_id: API request ID for debugging
    """

    files: list[FileItem]
    missing: list[str]
    request_submitted: bool
    async_request_id: str | None
    request_id: str

    @classmethod
    def from_response(cls, data: dict[str, Any], request_id: str) -> "FilesFromUrlsResult":
        """Create a FilesFromUrlsResult from an API response."""
        return cls(
            files=[FileItem.from_dict(f) for f in data.get("files", [])],
            missing=data.get("missing", []),
            request_submitted=data["request_submitted"],
            async_request_id=data.get("async_request_id"),
            request_id=request_id,
        )


@dataclass
class WebhookSubscription:
    """
    Represents a webhook subscription.

    Attributes:
        id: Unique webhook subscription ID (UUID)
        url: Webhook endpoint URL
        enabled: Whether the webhook is active
        created_at: ISO 8601 timestamp of creation
        updated_at: ISO 8601 timestamp of last update (optional)
    """

    id: str
    url: str
    enabled: bool
    created_at: str
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WebhookSubscription":
        """Create a WebhookSubscription from an API response dictionary."""
        return cls(
            id=data["id"],
            url=data["url"],
            enabled=data["enabled"],
            created_at=data["created_at"],
            updated_at=data.get("updated_at"),
        )
