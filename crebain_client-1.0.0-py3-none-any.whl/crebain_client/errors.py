"""
Crebain API error classes.

All API errors include the request_id for debugging and support.
"""

from typing import Any


class ApiError(Exception):
    """
    Base exception for all Crebain API errors.

    Attributes:
        code: Machine-readable error code (e.g., 'UNAUTHORIZED', 'RATE_LIMITED')
        message: Human-readable error description
        request_id: Unique request identifier for debugging
        status_code: HTTP status code
        response_body: Raw response body for debugging
    """

    def __init__(
        self,
        code: str,
        message: str,
        request_id: str | None = None,
        status_code: int | None = None,
        response_body: Any = None,
    ) -> None:
        self.code = code
        self.message = message
        self.request_id = request_id
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(f"[{code}] {message} (request_id={request_id})")

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(code={self.code!r}, message={self.message!r}, "
            f"request_id={self.request_id!r}, status_code={self.status_code!r})"
        )


class UnauthorizedError(ApiError):
    """Raised when authentication fails (401)."""

    pass


class ForbiddenError(ApiError):
    """Raised when the API key lacks required permissions (403)."""

    pass


class NotFoundError(ApiError):
    """Raised when a requested resource is not found (404)."""

    pass


class ConflictError(ApiError):
    """Raised on idempotency conflicts or resource state conflicts (409)."""

    pass


class ValidationError(ApiError):
    """Raised when request validation fails (422)."""

    pass


class RateLimitedError(ApiError):
    """Raised when rate limit is exceeded (429)."""

    pass


class InternalError(ApiError):
    """Raised on server-side errors (500)."""

    pass


def raise_for_error(status_code: int, response_body: Any) -> None:
    """
    Parse an error response and raise the appropriate exception.

    Args:
        status_code: HTTP status code
        response_body: Parsed JSON response body or raw string

    Raises:
        ApiError: Or a subclass based on the error code
    """
    if isinstance(response_body, dict) and "error" in response_body:
        error = response_body["error"]
        code = error.get("code", "UNKNOWN")
        message = error.get("message", "Unknown error")
        request_id = error.get("request_id")
    else:
        code = "UNKNOWN"
        message = str(response_body) if response_body else "Unknown error"
        request_id = None

    # Map error codes to exception classes
    error_class_map: dict[str, type[ApiError]] = {
        "UNAUTHORIZED": UnauthorizedError,
        "API_KEY_REVOKED": UnauthorizedError,
        "API_KEY_EXPIRED": UnauthorizedError,
        "FORBIDDEN": ForbiddenError,
        "NOT_FOUND": NotFoundError,
        "CONFLICT": ConflictError,
        "VALIDATION_ERROR": ValidationError,
        "RATE_LIMITED": RateLimitedError,
        "INTERNAL": InternalError,
    }

    # Also map by status code as fallback
    status_class_map: dict[int, type[ApiError]] = {
        401: UnauthorizedError,
        403: ForbiddenError,
        404: NotFoundError,
        409: ConflictError,
        422: ValidationError,
        429: RateLimitedError,
        500: InternalError,
    }

    error_class = error_class_map.get(code) or status_class_map.get(status_code, ApiError)

    raise error_class(
        code=code,
        message=message,
        request_id=request_id,
        status_code=status_code,
        response_body=response_body,
    )
