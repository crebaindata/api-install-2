"""
Webhook signature verification utilities.

Use these to verify incoming webhook requests from the Crebain API.
"""

import hashlib
import hmac


def verify_signature(
    secret: str,
    timestamp: str,
    raw_body: bytes,
    signature_header: str,
) -> bool:
    """
    Verify a webhook signature.

    The signature is computed as HMAC-SHA256 of "{timestamp}.{raw_body}"
    using your webhook secret as the key.

    Args:
        secret: Your webhook secret (the one you provided when creating the subscription)
        timestamp: Value of the X-Crebain-Timestamp header
        raw_body: Raw request body as bytes (do NOT parse or modify)
        signature_header: Value of the X-Crebain-Signature header (format: "v1=<hex>")

    Returns:
        True if the signature is valid, False otherwise

    Example:
        >>> # In your webhook handler (e.g., Flask)
        >>> @app.route('/webhook', methods=['POST'])
        >>> def handle_webhook():
        ...     timestamp = request.headers.get('X-Crebain-Timestamp')
        ...     signature = request.headers.get('X-Crebain-Signature')
        ...     raw_body = request.get_data()
        ...
        ...     if not verify_signature(WEBHOOK_SECRET, timestamp, raw_body, signature):
        ...         return 'Invalid signature', 401
        ...
        ...     event = request.json
        ...     # Process the event...
        ...     return 'OK', 200

    Security Notes:
        - Always use the raw bytes of the request body
        - Use timing-safe comparison (this function does)
        - Verify before parsing the JSON body
    """
    if not signature_header.startswith("v1="):
        return False

    expected_sig = signature_header[3:]  # Remove "v1=" prefix

    # Construct the canonical payload: timestamp.body
    payload = f"{timestamp}.".encode("utf-8") + raw_body

    # Compute HMAC-SHA256
    computed_sig = hmac.new(
        key=secret.encode("utf-8"),
        msg=payload,
        digestmod=hashlib.sha256,
    ).hexdigest()

    # Timing-safe comparison
    return hmac.compare_digest(computed_sig, expected_sig)


def compute_signature(secret: str, timestamp: str, raw_body: bytes) -> str:
    """
    Compute a webhook signature (useful for testing).

    Args:
        secret: Webhook secret
        timestamp: Unix timestamp as string
        raw_body: Raw request body as bytes

    Returns:
        Signature in "v1=<hex>" format
    """
    payload = f"{timestamp}.".encode("utf-8") + raw_body
    sig = hmac.new(
        key=secret.encode("utf-8"),
        msg=payload,
        digestmod=hashlib.sha256,
    ).hexdigest()
    return f"v1={sig}"
